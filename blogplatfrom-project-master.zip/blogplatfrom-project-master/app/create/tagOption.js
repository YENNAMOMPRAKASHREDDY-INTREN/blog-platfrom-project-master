export const tagOption = [
  {
    label: "javascript",
    value: "javascript",
  },
  {
    label: "webdev",
    value: "webdev",
  },
  {
    label: "beginners",
    value: "beginners",
  },
  {
    label: "programming",
    value: "programming",
  },
  {
    label: "tutorials",
    value: "tutorials",
  },
  {
    label: "react",
    value: "react",
  },
  {
    label: "python",
    value: "python",
  },
  {
    label: "productivity",
    value: "productivity",
  },
  {
    label: "css",
    value: "css",
  },
  {
    label: "devops",
    value: "devops",
  },
  {
    label: "android",
    value: "android",
  },
  {
    label: "discuss",
    value: "discuss",
  },
  {
    label: "career",
    value: "career",
  },
  {
    label: "node",
    value: "node",
  },
  {
    label: "opensource",
    value: "opensource",
  },
  {
    label: "aws",
    value: "aws",
  },
  {
    label: "html",
    value: "html",
  },
  {
    label: "codenewbie",
    value: "codenewbie",
  },
  {
    label: "typescript",
    value: "typescript",
  },
  {
    label: "java",
    value: "java",
  },
  {
    label: "github",
    value: "github",
  },
  {
    label: "testing",
    value: "testing",
  },
  {
    label: "security",
    value: "security",
  },
  {
    label: "php",
    value: "php",
  },
  {
    label: "mobile",
    value: "mobile",
  },
  {
    label: "showdev",
    value: "showdev",
  },
  {
    label: "database",
    value: "database",
  },
  {
    label: "docker",
    value: "docker",
  },
  {
    label: "angular",
    value: "angular",
  },
  {
    label: "linux",
    value: "linux",
  },
  {
    label: "cloud",
    value: "cloud",
  },
  {
    label: "vue",
    value: "vue",
  },
  {
    label: "blockchain",
    value: "blockchain",
  },
  {
    label: "machinelearning",
    value: "machinelearning",
  },
  {
    label: "go",
    value: "go",
  },
  {
    label: "api",
    value: "api",
  },
  {
    label: "git",
    value: "git",
  },
  {
    label: "ruby",
    value: "ruby",
  },
  {
    label: "kubernetes",
    value: "kubernetes",
  },
  {
    label: "dotnet",
    value: "dotnet",
  },
  {
    label: "datascience",
    value: "datascience",
  },
  {
    label: "laravel",
    value: "laravel",
  },
  {
    label: "design",
    value: "design",
  },
  {
    label: "ai",
    value: "ai",
  },
  {
    label: "csharp",
    value: "csharp",
  },
  {
    label: "azure",
    value: "azure",
  },
  {
    label: "serverless",
    value: "serverless",
  },
  {
    label: "computerscience",
    value: "computerscience",
  },
];
